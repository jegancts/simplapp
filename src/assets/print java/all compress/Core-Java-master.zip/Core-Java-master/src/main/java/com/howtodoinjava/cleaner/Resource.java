package com.howtodoinjava.cleaner;

public class Resource {
  //Demo resource
}

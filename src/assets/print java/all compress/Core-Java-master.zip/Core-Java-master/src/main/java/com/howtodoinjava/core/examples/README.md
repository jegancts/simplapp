# Related Tutorials

1. [Java - Program to calculate average of N numbers](https://howtodoinjava.com/java-programs/calculate-average-of-n-numbers/)
2. [Java - Console Input and Output Examples](https://howtodoinjava.com/java-programs/console-input-output/)
3. [Java - Program to Add Two Integers](https://howtodoinjava.com/java-programs/program-to-add-two-integers/)
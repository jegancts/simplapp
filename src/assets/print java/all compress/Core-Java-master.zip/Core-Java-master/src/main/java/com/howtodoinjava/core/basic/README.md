# Related Tutorials

1. [Java 14 - switch expression](https://howtodoinjava.com/java14/switch-expressions/)
2. [Java 14 - yield keyword](https://howtodoinjava.com/java14/yield-keyword-in-java/)
3. [Java 14 - Better NullPointerException](https://howtodoinjava.com/java14/helpful-nullpointerexception/)
4. [Java 14 - Text blocks and best practices](https://howtodoinjava.com/java14/java-text-blocks/)
5. [Java 14 - record type](https://howtodoinjava.com/java14/java-14-record-type/)
6. [Java 14 - Pattern Matching for instanceof](https://howtodoinjava.com/java14/pattern-matching-instanceof/)
7. [Java While Loop](https://howtodoinjava.com/java/basics/while-loop-in-java/)
8. [Java String substring()](https://howtodoinjava.com/java/string/java-string-substring-example/)
9.
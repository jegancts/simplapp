package com.howtodoinjava.core.basic;

public class BusinessCustomer extends Customer
{
	private String legalName;

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
}

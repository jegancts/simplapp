package com.howtodoinjava.core.datetime;

public class ValidateMultipleDateFormats {
  public static void main(String[] args) {
    //TODO
  }
}

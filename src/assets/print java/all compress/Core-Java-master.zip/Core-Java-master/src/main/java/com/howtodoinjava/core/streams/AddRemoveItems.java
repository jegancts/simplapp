package com.howtodoinjava.core.streams;

public class AddRemoveItems {
  public static void main(String[] args) {

  }
}

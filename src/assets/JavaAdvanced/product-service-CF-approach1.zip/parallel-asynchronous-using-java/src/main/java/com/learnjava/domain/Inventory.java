package com.learnjava.domain;

public class Inventory {
}

package com.userdetail.microservice.controller;

import com.userdetail.microservice.entity.UserDetails;
import com.userdetail.microservice.service.UserContactDetailsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.annotations.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@Api(tags = {"UserDetail"})
@SwaggerDefinition(tags = {@Tag(name = "UserDetailController", description = "User Detail REST API")})
public class UserContactDetailsController {

    private static final Logger logger = LoggerFactory.getLogger(UserContactDetailsController.class);

    @Autowired
    private UserContactDetailsService userContactDetailsService;

    @PostMapping("/user")
    public ResponseEntity saveUser(@RequestBody UserDetails userContactDetails){
        logger.info("User contact details - {}", userContactDetails);
        return userContactDetailsService.saveUserDetailservice(userContactDetails);
    }

    @GetMapping("/user/{ids}")
    public ResponseEntity getUsersByIds(@RequestParam ("ids") String ids)  {
        return userContactDetailsService.getUserDetailbyIds(ids);
    }

    @GetMapping("/users")
    public ResponseEntity getAllUsers() {
        return userContactDetailsService.getAllUserDetailService();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity getUserById(@PathVariable long id) {
        return userContactDetailsService.getUserDetailService(id);
    }

    @DeleteMapping ("/user/{id}")
    public ResponseEntity deleteUserById(@PathVariable long id) {
       return userContactDetailsService.deleteUserDetailService(id);
    }



    /*@PutMapping("/user/{id}")
    public ResponseEntity<UserDetails> updateUserById(@PathVariable long id,
                            @Valid @RequestBody UserDetails userDetails) throws UserNotFoundException {
        *//*Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeId));

        employee.setEmailId(employeeDetails.getEmailId());
        employee.setLastName(employeeDetails.getLastName());
        employee.setFirstName(employeeDetails.getFirstName());
        final Employee updatedEmployee = employeeRepository.save(employee);
        return ResponseEntity.ok(updatedEmployee);*//*
        return userContactDetailsService.updateUser(id,userDetails);
    }*/


}

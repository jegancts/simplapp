package com.userdetail.microservice.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="Address")
public class Address  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="door_no")
    private long doorNo;

    @Column(name="street_name")
    private String streetName;

    @Column(name="post_code")
    private String postCode;



   /* @JsonIgnore
    @OneToOne(mappedBy = "address")
    private User user;*/

}

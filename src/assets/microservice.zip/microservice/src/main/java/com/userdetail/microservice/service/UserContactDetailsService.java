package com.userdetail.microservice.service;

import com.userdetail.microservice.entity.UserDetails;
import com.userdetail.microservice.exceptions.UserNotFoundException;
import com.userdetail.microservice.dao.UserContactDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserContactDetailsService {

    @Autowired
    private UserContactDetailsRepository userContactDetailsRepository;

    public ResponseEntity saveUserDetailservice(UserDetails userDetails) {

        return new ResponseEntity(userContactDetailsRepository.save(userDetails),HttpStatus.ACCEPTED);
    }

    public ResponseEntity getUserDetailService(Long id) {

        Optional<UserDetails> userDetails = userContactDetailsRepository.findById(id);
        if(!userDetails.isEmpty())
           return new ResponseEntity(userDetails.get(), HttpStatus.OK);
       return new ResponseEntity(new UserNotFoundException("User Details not found in the database"), HttpStatus.NOT_FOUND);
    }

    public ResponseEntity getAllUserDetailService() {
        List<UserDetails> getAllUsers = userContactDetailsRepository.findAll();
        if (!getAllUsers.isEmpty())
            return new ResponseEntity<>(getAllUsers, HttpStatus.OK);
        return new ResponseEntity(new UserNotFoundException("User Contact Details not found in the database"), HttpStatus.NOT_FOUND);
    }

    public ResponseEntity deleteUserDetailService(long id) {

        UserDetails userDetails = userContactDetailsRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found for this id :: " + id));
        userContactDetailsRepository.deleteById(id);
        return new ResponseEntity<>("User Detail has been deleted for Id : "+id,HttpStatus.OK);

    }

    public ResponseEntity getUserDetailbyIds(String ids) {
        List<Long> listIds = Stream.of(ids.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());
       return new ResponseEntity<>(listIds.stream().map(a-> userContactDetailsRepository.findById(a).get()).collect(Collectors.toList()),HttpStatus.OK);
    }
}

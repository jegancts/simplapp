package com.userdetail.microservice.controlller;

public class UserContactDetailsControllerTest {
}
